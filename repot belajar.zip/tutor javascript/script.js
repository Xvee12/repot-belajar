// DOM Selection
// document.getElementById()
const judul = document.getElementsById('judul');