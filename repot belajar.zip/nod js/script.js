// DOM Selection
// document.getElementById()
const judul = document.getElementById('judul');
judul.style.color = 'Blue';
judul.style.backgroundColor = '#333';
judul.innerHTML = 'Agus saputra';

//document.getElementByTagName()
//-> HTMCollections
const p = document.getElementsByTagName('p');
p[0].style.backgroundColor = 'lightblue';
p[1].style.backgroundColor = 'lightblue';
p[2].style.backgroundColor = 'green';
p[2].style.color = 'red';

const h1 = document.getElementsByTagName('h1')[0];
h1.style.fontSize = '50px';

// document.getElementByClassName()
// -> HTMCollection
const p1 = document.getElementsByClassName('p1')[0];
p1.innerHTML = 'situ gacor kang';

// document.querySelector() ->element
const p4 = document.querySelector('#b p');
p4.style.color = 'yellow';
p4.style.backgroundColor = 'red';

const li2 = document.querySelector('section#b ul li:nth-child(2)');
li2.style.backgroundColor = 'purple';
li2.style.color = 'blue';


