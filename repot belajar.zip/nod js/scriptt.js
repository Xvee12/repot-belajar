// const judul = document.getElementById('judul');
// judul.innerHTML = '<em>Agus Saputra</em>';

// const sectionA = document.querySelector('section#a');
// sectionA.innerHTML = 'Hello World';


// const judul = document.querySelector('#judul');
// judul.style.color = 'yellow';
// judul.style.backgroundColor = 'purple';


// const judul = document.getElementsByTagName('h1')[0];

// judul.setAttribute('nama', 'agus');


//buat elemen baru
const pBaru = document.createElement('p');
const teksPBaru = document.createTextNode('paragraf Baru');
//simpan tulisan ke dalam paragraft
pBaru.appendChild(teksPBaru);

//simpan pBaru diakhir section A
const sectionA = document.getElementById('a');
sectionA.appendChild(pBaru);

const liBaru = document.createElement('li');
const teksLiBaru = document.createTextNode('itemBaru');
liBaru.appendChild(teksLiBaru);

const ul = document.querySelector('section#b ul');
const li2 = ul.querySelector('li:nth-child(2)');

ul.insertBefore(liBaru, li2);

//remove
const link = document.getElementsByTagName('a')[0];

sectionA.removeChild(link);


//replace
const sectionB = document.getElementById('b');
const p4 = sectionB.querySelector('p');

const h2Baru = document.createElement('h2');
const teksH2Baru = document.createTextNode('judulBaru!');

h2Baru.appendChild(teksH2Baru);

sectionB.replaceChild(h2Baru, p4);

pBaru.style.backgroundColor = 'blue';
liBaru.style.backgroundColor = 'blue';
h2Baru.style.backgroundColor = 'blue';

