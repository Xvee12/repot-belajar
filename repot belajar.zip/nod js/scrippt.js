const p3 = document.querySelector('.p3');


function ubahWarna() {
    p3.style.backgroundColor = 'red';
}


const p2 = document.querySelector('.p3');
p2.onclick = ubahWarna;


const p4 = document.querySelector('section#b p');
p4.addEventListener('click', function() {
    alert('ok');
});