const tUbahWarna = document.getElementById('tUbahWarna')
tUbahWarna.onclick = function() {
    document.body.style.backgroundColor = 'red';
}